package ifpb.aps.cookit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import com.google.android.material.textfield.TextInputLayout;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Recuperar_senha extends AppCompatActivity {

    TextInputLayout textInputLayout;
    AppCompatButton button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recuperar_senha);

        textInputLayout = findViewById(R.id.emailRecuperar);
        button = findViewById(R.id.btnEnviarLink);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = textInputLayout.getEditText().getText().toString();
                Log.w("Login", "Email do link: " + email);
                Intent telaHome = new Intent(Recuperar_senha.this, HomeActivity.class);
                startActivity(telaHome);
            }
        });
    }
}
