package ifpb.aps.cookit;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Novo_user_pt2 extends AppCompatActivity {

    EditText CampoNome, CampoIdade, CampoOcupacao;
    Button concluirPerfil, pularEtapa;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_novo_user_pt2);

        CampoNome = findViewById(R.id.etNomeCadastros);
        CampoIdade = findViewById(R.id.etIdadeCadastros);
        CampoOcupacao = findViewById(R.id.etOcupacaoCadastro);

        concluirPerfil = findViewById(R.id.btnConcluirPerfilCadastro);
        pularEtapa = findViewById(R.id.btnPularEtapaCadastro);

        concluirPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent telaHome = new Intent(getApplicationContext(), Meu_perfil.class);
                String nome, idade, ocupacao;
                nome = CampoNome.getText().toString();
                idade = CampoIdade.getText().toString();
                ocupacao = CampoOcupacao.getText().toString();
                Log.w("Login", "Criar conta 2 Nome : " + nome);
                Log.w("Login", "Criar conta 2 Idade : " + idade);
                Log.w("Login", "Criar conta 2 Ocupacao : " + ocupacao);
                startActivity(telaHome);
                finish();
            }
        });

        pularEtapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent telaHome = new Intent(getApplicationContext(), HomeActivity.class);
                startActivity(telaHome);
                finish();
            }
        });
    }
}