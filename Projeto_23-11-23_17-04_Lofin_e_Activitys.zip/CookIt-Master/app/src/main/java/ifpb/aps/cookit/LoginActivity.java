package ifpb.aps.cookit;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import io.reactivex.annotations.NonNull;

public class LoginActivity extends AppCompatActivity {
    private EditText etEmailLogin;
    private EditText etSenhaLogin;
    private Button btnLogar;
    private Button btnCriarConta;
    private Button btnConvidado;
    TextView textView;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_inicial);

        mAuth = FirebaseAuth.getInstance();
        etEmailLogin = findViewById(R.id.areaDeEmail);
        etSenhaLogin = findViewById(R.id.areaDeSenha);
        btnLogar = findViewById(R.id.btnLogar);
        btnCriarConta = findViewById(R.id.btnCriarConta);
        btnConvidado = findViewById(R.id.btn_convidado);
        textView = findViewById(R.id.btnResetarSenha);

        btnLogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email, senha;
                email = String.valueOf(etEmailLogin.getText());
                senha = String.valueOf(etSenhaLogin.getText());
                Log.w("Login"," email : " + email);
                Log.w("Login"," senha : " + senha);

                if(TextUtils.isEmpty(email)){
                    Toast.makeText(getApplicationContext(), "Entre com seu email", Toast.LENGTH_SHORT).show();
                    return;

                }
                if(TextUtils.isEmpty(senha)){
                    Toast.makeText(getApplicationContext(), "Entre com sua senha", Toast.LENGTH_SHORT).show();
                    return;
                }
                mAuth.signInWithEmailAndPassword(email, senha)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(getApplicationContext(), "login efetuado com sucesso",
                                            Toast.LENGTH_SHORT).show();
                                    Intent telaHome = new Intent(getApplicationContext(), HomeActivity.class);
                                    startActivity(telaHome);
                                    finish();

                                } else {
                                    Toast.makeText(getApplicationContext(), "Falha no login",
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });

        btnCriarConta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent telaHome = new Intent(LoginActivity.this, Novo_usuario_pt1.class);
                startActivity(telaHome);
                finish();
            }
        });

        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent telaHome = new Intent(LoginActivity.this, Recuperar_senha.class);
                startActivity(telaHome);
                finish();
            }
        });

        btnConvidado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent telaHome = new Intent(LoginActivity.this, Novo_user_pt2.class);
                startActivity(telaHome);
                finish();
            }
        });
    }
}