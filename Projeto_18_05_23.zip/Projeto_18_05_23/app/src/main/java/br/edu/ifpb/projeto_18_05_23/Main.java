package br.edu.ifpb.projeto_18_05_23;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main extends AppCompatActivity {

    private Button btnTela1;
    private Button btnTela2;
    private Button btnTela3;
    private Button btnTela4;
    private Button btnLigar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnTela2 = findViewById(R.id.btn1);
        btnTela2 = findViewById(R.id.btn2);
        btnTela3 = findViewById(R.id.btn2);
        btnTela4 = findViewById(R.id.btn2);
//        btnLigar = findViewById(R.id.btnLigar);

        btnTela1.setOnClickListener( new Main.Btn1ClickListener() );
        btnTela2.setOnClickListener( new Main.Btn2ClickListener() );
        btnTela3.setOnClickListener( new Main.Btn3ClickListener() );
        btnTela4.setOnClickListener( new Main.Btn4ClickListener() );

    }
    private class BtnLigarListener implements View
            .OnClickListener{
        @Override
        public void onClick(View view) {
            Uri numeroTelefone = Uri.parse("tel:83999999999");
            //Intent abrirDiscador = new Intent(Main.this, numeroTelefone.class);

        }
    }
    private class Btn1ClickListener implements View
            .OnClickListener{
        @Override
        public void onClick(View view) {
            Intent tela1 = new Intent(Main.this, Tela_1.class);
            startActivity(tela1);
        }
    }
    private class Btn2ClickListener implements View
            .OnClickListener{
        @Override
        public void onClick(View view) {
            Intent tela2 = new Intent(Main.this, Tela_2.class);
            startActivity(tela2);
        }
    }
    private class Btn3ClickListener implements View
            .OnClickListener{
        @Override
        public void onClick(View view) {
            Intent tela3 = new Intent(Main.this, Tela_3.class);
            startActivity(tela3);
        }
    }
    private class Btn4ClickListener implements View
            .OnClickListener{
        @Override
        public void onClick(View view) {
            Intent tela4 = new Intent(Main.this, Tela_4.class);
            startActivity(tela4);
        }
    }
}