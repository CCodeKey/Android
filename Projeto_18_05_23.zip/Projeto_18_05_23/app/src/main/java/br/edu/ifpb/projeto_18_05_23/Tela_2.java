package br.edu.ifpb.projeto_18_05_23;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Tela_2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);
    }
}