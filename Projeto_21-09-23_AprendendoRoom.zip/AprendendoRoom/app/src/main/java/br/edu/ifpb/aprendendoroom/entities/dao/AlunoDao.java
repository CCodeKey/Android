package br.edu.ifpb.aprendendoroom.entities.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import br.edu.ifpb.aprendendoroom.entities.Aluno;

@Dao
public interface AlunoDao {
             //CRUD
    //Inserindo aluno
    @Insert
    void create(Aluno... alunos);

    //Listar aluno apartir do id / matricula
    @Query("Select * from aluno where uid=:id")
    Aluno readById(int id);

    @Query("Select * from aluno where uid=:matricula limit 1")
    Aluno readByMatriucla(int matricula);

    //Listar todos
    @Query("Select * from aluno")
    List<Aluno> readAll();

    //Atualizando aluno
    @Update
    void update(Aluno aluno);

    //Deletando aluno
    @Delete
    void delete(Aluno aluno);
}