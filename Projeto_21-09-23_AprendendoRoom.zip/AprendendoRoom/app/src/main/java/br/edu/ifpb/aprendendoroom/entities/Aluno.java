package br.edu.ifpb.aprendendoroom.entities;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Aluno {
    @PrimaryKey(autoGenerate = true)
    private int uid;
    @ColumnInfo
    private String nomeComleto;
    @ColumnInfo
    private int matricula;
    @ColumnInfo
    private String email;

    public Aluno (){}

    public Aluno(String nomeComleto, int matricula, String email) {
        this.uid = uid;
        this.nomeComleto = nomeComleto;
        this.matricula = matricula;
        this.email = email;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getNomeComleto() {
        return nomeComleto;
    }

    public void setNomeComleto(String nomeComleto) {
        this.nomeComleto = nomeComleto;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    @Override
    public String toString() {
        return "Aluno{" +
                "uid=" + uid +
                ", nomeComleto='" + nomeComleto + '\'' +
                ", matricula=" + matricula +
                ", email='" + email + '\'' +
                '}';
    }
}
