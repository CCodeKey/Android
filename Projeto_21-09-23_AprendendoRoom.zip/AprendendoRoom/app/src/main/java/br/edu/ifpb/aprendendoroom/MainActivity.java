package br.edu.ifpb.aprendendoroom;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.os.Bundle;
import android.util.Log;

import br.edu.ifpb.aprendendoroom.entities.Aluno;
import br.edu.ifpb.aprendendoroom.repository.AppDataBase;

public class MainActivity extends AppCompatActivity {

    final String TAG = "demo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AppDataBase db = Room.databaseBuilder(this, AppDataBase.class, "Aluno.db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                    .build();

        Log.d(TAG, "onCreate "+ db.alunoDao().readAll());
        db.alunoDao().create(
                new Aluno("Code Key", 2016610015,"newcodiguin@gmail.com")
        );
        Log.d(TAG, "onCreate "+ db.alunoDao().readAll());

    }
}