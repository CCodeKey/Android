package br.edu.ifpb.aprendendoroom.repository;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import br.edu.ifpb.aprendendoroom.entities.Aluno;
import br.edu.ifpb.aprendendoroom.entities.dao.AlunoDao;

@Database(version = 1, entities = {Aluno.class})
public abstract class AppDataBase extends RoomDatabase {
    public abstract AlunoDao alunoDao();
}
