package br.edu.ifpb.listadinamica;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class ListaActivity extends AppCompatActivity {
    private ListView lvPaises;
    private FloatingActionButton fabAddPais;
    private List<String> listaPaises;
    private ArrayAdapter listaPaisesAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);
        lvPaises = findViewById(R.id.lvPaises);
        fabAddPais = findViewById(R.id.fabAddPais);
        listaPaises = new ArrayList<String>();
        listaPaisesAdapter = new ArrayAdapter<String>(this , android.R.layout.simple_list_item_1, listaPaises);
        lvPaises.setAdapter(listaPaisesAdapter);
        fabAddPais.setOnClickListener(new fabAddPaiOnClickListener());

    }

    private class fabAddPaiOnClickListener implements View .OnClickListener{
            @Override
            public void onClick(View view){

            }
    }

}