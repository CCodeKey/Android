package br.edu.ifpb.listadinamica;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;

public class CadastroPaisAlertDialog extends DialogFragment {
    private EditText enEntradaPais;
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View formCadastroPais = inflater.inflate(R.layout.formcadastropais_alertdialog, null);

        enEntradaPais = formCadastroPais.findViewById(R.id.etEntradaPais);
        builder
                .setTitle("Novo País")
                .setView(formCadastroPais)
                .setPositiveButton(R.string.cadastrar, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String pais = String.valueOf(enEntradaPais.getText());
                        Log.i("APP", pais);
                    }
                });
        return builder.create();
    }
}