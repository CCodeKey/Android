package br.edu.ifpb.listadinamica;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;

public class CadastroPaisAlertDialog extends DialogFragment {
    private EditText enEntradaPais;
    private CadastroListener cadastroListener;
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View formCadastroPais = inflater.inflate(R.layout.formcadastropais_alertdialog, null);

        enEntradaPais = formCadastroPais.findViewById(R.id.etEntradaPais);
        builder
                .setTitle("Novo País")
                .setView(formCadastroPais)
                .setPositiveButton(R.string.cadastrar, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String pais = String.valueOf(enEntradaPais.getText());
                        cadastroListener.cadastrarPais(pais);
                        Log.i("APP", pais);
                    }
                });
        return builder.create();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            cadastroListener = (CadastroListener) context;
        }catch (ClassCastException error){
            throw new ClassCastException(context.toString() + "precisa implementar a interface CadastroListener");
        }
    }

    public interface CadastroListener{
        void cadastrarPais(String pais);
    }
}