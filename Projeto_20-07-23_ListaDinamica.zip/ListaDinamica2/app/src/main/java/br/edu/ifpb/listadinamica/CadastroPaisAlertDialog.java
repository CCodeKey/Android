//package br.edu.ifpb.listadinamica;
//
//import android.app.AlertDialog;
//import android.app.Dialog;
//import android.content.Context;
//import android.content.DialogInterface;
//import android.os.Bundle;
//import android.util.Log;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.widget.EditText;
//
//import androidx.annotation.NonNull;
//import androidx.annotation.Nullable;
//import androidx.fragment.app.DialogFragment;
//import androidx.fragment.app.FragmentManager;
//
//public class CadastroPaisAlertDialog extends DialogFragment {
//    private EditText enEntradaPais;
//    private CadastroListener cadastroListener;
//    @NonNull
//    @Override
//    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
//        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
//
//        LayoutInflater inflater = requireActivity().getLayoutInflater();
//        View formCadastroPais = inflater.inflate(R.layout.formcadastropais_alertdialog, null);
//
//        enEntradaPais = formCadastroPais.findViewById(R.id.etEntradaPais);
//        builder
//                .setTitle("Novo País")
//                .setView(formCadastroPais)
//                .setPositiveButton(R.string.cadastrar, new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialogInterface, int i) {
//                        String pais = String.valueOf(enEntradaPais.getText());
//                        cadastroListener.cadastrarPais(pais);
//                        Log.i("APP", pais);
//                    }
//                });
//        return builder.create();
//    }
//
//    @Override
//    public void onAttach(@NonNull Context context) {
//        super.onAttach(context);
//        try {
//            cadastroListener = (CadastroListener) context;
//        }catch (ClassCastException error){
//            throw new ClassCastException(context.toString() + "precisa implementar a interface CadastroListener");
//        }
//    }
//
//    public interface CadastroListener{
//        void cadastrarPais(String pais);
//    }
//}

















package br.edu.ifpb.listadinamica;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;

public class CadastroPaisAlertDialog extends DialogFragment {
    private EditText enEntradaPais;
    private CadastroListener cadastroListener;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        // Cria um novo AlertDialog.Builder associado à atividade atual
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        // Obtém o Inflater para inflar o layout personalizado
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View formCadastroPais = inflater.inflate(R.layout.formcadastropais_alertdialog, null);

        // Encontra a EditText para entrada do país no layout inflado
        enEntradaPais = formCadastroPais.findViewById(R.id.etEntradaPais);

        // Configura o AlertDialog com título, layout personalizado e botão positivo
        builder
                .setTitle("Novo País")
                .setView(formCadastroPais)
                .setPositiveButton(R.string.cadastrar, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Quando o botão de cadastro é clicado, obtém o texto da entrada do país
                        String pais = String.valueOf(enEntradaPais.getText());

                        // Chama o método cadastrarPais no cadastroListener passando o nome do país
                        cadastroListener.cadastrarPais(pais);

                        // Registra o nome do país no log
                        Log.i("APP", pais);
                    }
                });
        return builder.create(); // Retorna o AlertDialog configurado
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            // Tenta vincular o contexto à interface CadastroListener
            cadastroListener = (CadastroListener) context;
        } catch (ClassCastException error) {
            // Se o contexto não implementar a interface, gera uma exceção
            throw new ClassCastException(context.toString() + " precisa implementar a interface CadastroListener");
        }
    }

    // Interface para ser implementada pela atividade que usa o AlertDialog
    public interface CadastroListener {
        void cadastrarPais(String pais);
    }
}
