package ifpb.aps.cookit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.google.android.material.textfield.TextInputLayout;

public class Novo_usuario_pt2 extends AppCompatActivity {
//    TextInputLayout nome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_novo_usuario_pt2);

//        nome = findViewById(R.id.textInputLayout_6);
    }
}