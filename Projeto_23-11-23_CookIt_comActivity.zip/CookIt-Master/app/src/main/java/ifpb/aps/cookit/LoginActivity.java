package ifpb.aps.cookit;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
public class LoginActivity extends AppCompatActivity {
    private EditText etEmailLogin;
    private EditText etSenhaLogin;
    private Button btnLogar;
    private Button btnCriarConta;
    private Button btnConvidado;

    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_inicial);

        etEmailLogin = findViewById(R.id.areaDeEmail);
        etSenhaLogin = findViewById(R.id.areaDeSenha);
        btnLogar = findViewById(R.id.btnLogar);
        btnCriarConta = findViewById(R.id.btnCriarConta);
        btnConvidado = findViewById(R.id.btn_convidado);
        textView = findViewById(R.id.btnResetarSenha);

        btnLogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent telaHome = new Intent(LoginActivity.this, HomeActivity.class);
                String email;
//                email = String.valueOf(etEmailLogin.getText());
//                Log.w("Login"," email : " + email);
                startActivity(telaHome);
            }
        });

        btnCriarConta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent telaHome = new Intent(LoginActivity.this, Novo_usuario_pt1.class);
                startActivity(telaHome);
            }
        });

        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent telaHome = new Intent(LoginActivity.this, Recuperar_senha.class);
                startActivity(telaHome);
            }
        });

        btnConvidado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent telaHome = new Intent(LoginActivity.this, Novo_usuario_pt2.class);
                startActivity(telaHome);
            }
        });
    }
}