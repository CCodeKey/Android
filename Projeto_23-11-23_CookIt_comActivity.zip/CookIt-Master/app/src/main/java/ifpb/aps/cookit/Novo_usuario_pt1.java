package ifpb.aps.cookit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Novo_usuario_pt1 extends AppCompatActivity {

    AppCompatEditText campoEmail, campoSenha1, camporSenha2;
    AppCompatButton btncriartela2, btnVoltarLogin, btnConvidado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_novo_usuario_pt1);

        campoEmail = findViewById(R.id.etEmailCadastro);
        campoSenha1 = findViewById(R.id.areaDeSenha);
        camporSenha2 = findViewById(R.id.etConfirmarSenhaCadastro);

        btncriartela2 = findViewById(R.id.btnContinuarCadastro);
        btnVoltarLogin = findViewById(R.id.btnVoltarParaLogin);
        btnConvidado = findViewById(R.id.btnContinuarComoConvidadoCadastro);

        btncriartela2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent telaHome = new Intent(Novo_usuario_pt1.this, Novo_usuario_pt2.class);
                startActivity(telaHome);
            }
        });

        btnVoltarLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent telaHome = new Intent(Novo_usuario_pt1.this, LoginActivity.class);
                startActivity(telaHome);
            }
        });

        btnConvidado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent telaHome = new Intent(Novo_usuario_pt1.this, Novo_usuario_pt2.class);
                startActivity(telaHome);
            }
        });
    }
}