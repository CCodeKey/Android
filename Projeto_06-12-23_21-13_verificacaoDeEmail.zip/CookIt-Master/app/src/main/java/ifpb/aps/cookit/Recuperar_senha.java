package ifpb.aps.cookit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import io.reactivex.annotations.NonNull;

public class Recuperar_senha extends AppCompatActivity {

    TextInputLayout textInputLayout;
    AppCompatButton button;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recuperar_senha);

        textInputLayout = findViewById(R.id.emailRecuperar);
        button = findViewById(R.id.btnEnviarLink);
        mAuth = FirebaseAuth.getInstance();

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email;
                email = textInputLayout.getEditText().getText().toString();
                Log.w("Login", "Email do link: " + email);

                if(TextUtils.isEmpty(email)){
                    Toast.makeText(getApplicationContext(), "Entre com seu email", Toast.LENGTH_SHORT).show();
                    return;
                }
                mAuth.sendPasswordResetEmail(email)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(getApplicationContext(), "E-mail de recuperação de senha enviado para " + email,
                                            Toast.LENGTH_SHORT).show();
                                    Intent telaHome = new Intent(getApplicationContext(), Nova_senha.class);
                                    startActivity(telaHome);
                                    finish();

                                } else {
                                    Exception exception = task.getException();
                                    if (exception != null) {
                                        Toast.makeText(getApplicationContext(),
                                                "Falha ao enviar e-mail de recuperação de senha: " + exception.getMessage(),
                                                Toast.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(getApplicationContext(),
                                                "Falha ao enviar e-mail de recuperação de senha",
                                                Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }
                        });
            }
        });
    }
}
