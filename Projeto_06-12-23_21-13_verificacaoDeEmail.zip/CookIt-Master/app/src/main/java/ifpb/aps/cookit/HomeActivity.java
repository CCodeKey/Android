package ifpb.aps.cookit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class HomeActivity extends AppCompatActivity {

    ImageButton My_perfil;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        My_perfil = findViewById(R.id.btnPerfilRodape);
        My_perfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent telaHome = new Intent(getApplicationContext(), Meu_perfil.class);
                startActivity(telaHome);
                finish();
            }
        });
    }
}