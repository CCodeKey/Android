package ifpb.aps.cookit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.ktx.Firebase;

import io.reactivex.annotations.NonNull;

public class Novo_usuario_pt1 extends AppCompatActivity {


    EditText campoEmail, campoSenha1, camporSenha2;
    AppCompatButton btnVoltarLogin, btnConvidado;
    Button btncriartela_2;

    FirebaseAuth mAuth;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_novo_usuario_pt1);

        campoEmail = findViewById(R.id.CemailNovoUer);
        campoSenha1 = findViewById(R.id.campoSenha1NovoUser);
        camporSenha2 = findViewById(R.id.campoSenha2NovoUser);
        mAuth = FirebaseAuth.getInstance();
        btncriartela_2 = findViewById(R.id.btnContinuarCadastro);
        btnVoltarLogin = findViewById(R.id.btnVoltarParaLogin);
        btnConvidado = findViewById(R.id.btnContinuarComoConvidadoCadastro);

        btncriartela_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email, senha1, senha2;
                email = campoEmail.getText().toString();
                senha1 = campoSenha1.getText().toString();
                senha2 = camporSenha2.getText().toString();
                Log.w("Login", "Criar conta Email : " + email);
                Log.w("Login", "Criar conta senha 1 : " + senha1);
                Log.w("Login", "Criar conta senha 2 : " + senha2);

                if (senha1.equals(senha2)){

                    if(TextUtils.isEmpty(email)){
                        Toast.makeText(getApplicationContext(), "Entre com seu email", Toast.LENGTH_SHORT).show();
                        return;

                    }
                    if(TextUtils.isEmpty(senha1)){
                        Toast.makeText(getApplicationContext(), "Entre com sua senha", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    mAuth.createUserWithEmailAndPassword(email, senha1)
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(getApplicationContext(), "Conta criada com sucesso",
                                                Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(getApplicationContext(), Novo_user_pt2.class);
                                        startActivity(intent);
                                        finish();

                                    } else {
                                        Toast.makeText(getApplicationContext(), "Falha na criação do usuario",
                                                Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                }
                else {
                    Toast.makeText(getApplicationContext(), "A senha está incorreta. Tente novamente !",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnVoltarLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent telaHome = new Intent(Novo_usuario_pt1.this, LoginActivity.class);
                startActivity(telaHome);
                finish();
            }
        });

        btnConvidado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent telaHome = new Intent(Novo_usuario_pt1.this, Novo_user_pt2.class);
                startActivity(telaHome);
                finish();
            }
        });
    }
}