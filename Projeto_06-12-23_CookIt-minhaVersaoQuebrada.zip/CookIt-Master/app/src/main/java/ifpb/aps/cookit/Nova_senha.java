package ifpb.aps.cookit;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import io.reactivex.annotations.NonNull;

public class Nova_senha extends AppCompatActivity {

    EditText senha, confirmacaoSenha;
    Button btnconfirmar;
    FirebaseAuth firebaseAuth;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nova_senha);

        senha = findViewById(R.id.senha_reset);
        confirmacaoSenha = findViewById(R.id.confirmacao_reset);
        btnconfirmar = findViewById(R.id.btnConfirmarReset);

        btnconfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String senha1, senha2;
                senha1 = String.valueOf(senha.getText());
                senha2 = String.valueOf(confirmacaoSenha.getText());
                Log.w("Login", "senha : " + senha1);
                Log.w("Login", "Confirmação da senha : " + senha2);

//                if (senha1.equals(senha2)){
                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

                if (user != null) {
                    Log.d("FirebaseUser", "UID: " + user.getUid());
                    Log.d("FirebaseUser", "E-mail: " + user.getEmail());
                } else {
                    Log.d("FirebaseUser", "Usuário não autenticado");
                }

                if (senha1.isEmpty()) {
                        Toast.makeText(getApplicationContext(), "Digite a nova senha !", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    user.updatePassword(senha1)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(getApplicationContext(),
                                                "Senha redefinida com sucesso !",
                                                Toast.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(getApplicationContext(),
                                                "Falha ao redefinir a senha",
                                                Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
//                }else {
//                    Toast.makeText(getApplicationContext(), "A senha está incorreta. Tente novamente !",
//                            Toast.LENGTH_SHORT).show();
//                }
            }
        });



    }
}