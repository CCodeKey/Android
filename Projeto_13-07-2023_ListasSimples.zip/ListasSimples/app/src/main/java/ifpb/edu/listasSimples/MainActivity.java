package ifpb.edu.listasSimples;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    private ListView listaPaises;
    private String [] paises = {"Brasil","França","Canáda","Argentina","Bélgica","Brasil","França","Canáda","Argentina","Bélgica","Brasil","França","Canáda","Argentina","Bélgica","Brasil","França","Canáda","Argentina","Bélgica"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Instanciando a variavel da lista
        this.listaPaises = findViewById(R.id.listaPaises);
        //Criando um listaAdaptavel                          (Local(onde vai estar) , android(como será apresentada a lista) , lista,  )
        ArrayAdapter<String> listaAdapterPaises = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, paises);
        //Mostrando na tela
        this.listaPaises.setAdapter(listaAdapterPaises);
    }
}